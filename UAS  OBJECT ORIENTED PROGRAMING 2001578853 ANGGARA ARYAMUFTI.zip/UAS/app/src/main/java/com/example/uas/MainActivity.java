package com.example.uas;
import java.util.Scanner;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        System.out.println("CHOOSE PlayerA HERO(lowercase)");
        System.out.println("infantry");
        System.out.println("cavalry");
        System.out.println("archer");
        System.out.println("catapult");
        Scanner hero = new Scanner(System.in);
        Heroes input1 = new Heroes();
        input1.Infantry = hero.nextLine();
        if(input1.Infantry.equals("infantry")) {
            System.out.println("Infantry (boost 40% attack infantry)");
        }else if(input1.Infantry.equals("cavalry")) {
            System.out.println("Cavalry (boost 40% attack Cavalry)");
        }else if(input1.Infantry.equals("archer")) {
            System.out.println("Archer (boost 40% attack Archer)");
        }else if(input1.Infantry.equals("catapult")) {
            System.out.println("Catapult (boost 40% attack Catapult)");
        }


        System.out.println("CHOOSE PlayerA ARMY(lowercase)");
        System.out.println("infantry");
        System.out.println("cavalry");
        System.out.println("archer");
        System.out.println("catapult");
        Scanner army = new Scanner(System.in);
        Heroes input2 = new Heroes();
        input2.Cavalry = army.nextLine();
        if(input2.Cavalry.equals("infantry")) {
            System.out.println("Infantry Armies");
        }else if(input2.Cavalry.equals("cavalry")) {
            System.out.println("Cavalry Armies");
        }else if(input2.Cavalry.equals("archer")) {
            System.out.println("Archer Armies");
        }else if(input2.Cavalry.equals("catapult")) {
            System.out.println("Catapult Armies");
        }

        System.out.println("CHOOSE PlayerB HERO(lowercase)");
        System.out.println("infantry");
        System.out.println("cavalry");
        System.out.println("archer");
        System.out.println("catapult");
        Scanner hero2 = new Scanner(System.in);
        Heroes input3 = new Heroes();
        input3.Infantry = hero2.nextLine();
        if(input3.Infantry.equals("infantry")) {
            System.out.println("Infantry (boost 40% attack infantry)");
        }else if(input3.Infantry.equals("cavalry")) {
            System.out.println("Cavalry (boost 40% attack Cavalry)");
        }else if(input3.Infantry.equals("archer")) {
            System.out.println("Archer (boost 40% attack Archer)");
        }else if(input3.Infantry.equals("catapult")) {
            System.out.println("Catapult (boost 40% attack Catapult)");
        }


        System.out.println("CHOOSE PlayerB ARMY(lowercase)");
        System.out.println("infantry");
        System.out.println("cavalry");
        System.out.println("archer");
        System.out.println("catapult");
        Scanner army2 = new Scanner(System.in);
        Heroes input4 = new Heroes();
        input4.Cavalry = army.nextLine();
        if(input4.Cavalry.equals("infantry")) {
            System.out.println("Infantry Armies");
        }else if(input4.Cavalry.equals("cavalry")) {
            System.out.println("Cavalry Armies");
        }else if(input4.Cavalry.equals("archer")) {
            System.out.println("Archer Armies");
        }else if(input4.Cavalry.equals("catapult")) {
            System.out.println("Catapult Armies");
        }
    }
}