package com.example.uas;

public class Heroes {
    String Infantry, Cavalry, Archer, Catapult;

    public String getInfantry() {
        return Infantry;
    }

    public void setInfantry(String infantry) {
        Infantry = infantry;
    }

    public String getCavalry() {
        return Cavalry;
    }

    public void setCavalry(String cavalry) {
        Cavalry = cavalry;
    }

    public String getArcher() {
        return Archer;
    }

    public void setArcher(String archer) {
        Archer = archer;
    }

    public String getCatapult() {
        return Catapult;
    }

    public void setCatapult(String catapult) {
        Catapult = catapult;
    }

    class Infantry extends Heroes {
        String Hero1 = "Infantry";
    }
    public void H1() {
        Infantry myInfantry = new Infantry();
        System.out.printf(myInfantry.Hero1);
        myInfantry.boost();
    }

    class Cavalry extends Heroes {
        String Hero2 = "Cavalry";
    }
    public void H2() {
        Cavalry myCavalry = new Cavalry();
        System.out.printf(myCavalry.Hero2);
        myCavalry.boost();
    }

    class Archer extends Heroes {
        String Hero3 = "Archer";
    }
    public void H3() {
        Archer myArcher = new Archer();
        System.out.printf(myArcher.Hero3);
        myArcher.boost();
    }

    class Catapult extends Heroes {
        String Hero4 = "Catapult";
    }
    public void H4() {
        Catapult myCatapult = new Catapult();
        System.out.printf(myCatapult.Hero4);
        myCatapult.boost();
    }

    public void boost() {
        System.out.println("(boost 40% attack)");
    }
}
