package com.example.uas;
import java.util.Scanner;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.ImageView;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        System.out.println("CHOOSE Player one HERO");
        System.out.println("infantry");
        System.out.println("cavalry");
        Scanner hero = new Scanner(System.in);
        Heroes input1 = new Heroes();
        input1.Infantry = hero.nextLine();
        if(input1.Infantry.equals("infantry")) {
            System.out.println("Infantry (boost 40% attack infantry)");
        }else if(input1.Infantry.equals("cavalry"))
            System.out.println("Cavalry (boost 40% attack Cavalry)");


        System.out.println("CHOOSE Player one ARMY");
        System.out.println("infantry");
        System.out.println("cavalry");
        Scanner army = new Scanner(System.in);
        Heroes input2 = new Heroes();
        input2.Cavalry = army.nextLine();
        if(input2.Cavalry.equals("infantry")) {
            System.out.println("Infantry Armies");
        }else if(input2.Cavalry.equals("cavalry")) {
            System.out.println("Cavalry Armies");

        }

        System.out.println("CHOOSE Player Two HERO");
        System.out.println("infantry");
        System.out.println("cavalry");
        Scanner hero2 = new Scanner(System.in);
        Heroes input3 = new Heroes();
        input3.Infantry = hero2.nextLine();
        if(input3.Infantry.equals("infantry")) {
            System.out.println("Infantry (boost 40% attack infantry)");
        }else if(input3.Infantry.equals("cavalry")) {
            System.out.println("Cavalry (boost 40% attack Cavalry)");
        }


        System.out.println("CHOOSE Player Two ARMY");
        System.out.println("infantry");
        System.out.println("cavalry");

        Scanner army2 = new Scanner(System.in);
        Heroes input4 = new Heroes();
        input4.Cavalry = army.nextLine();
        if(input4.Cavalry.equals("infantry")) {
            System.out.println("Infantry Armies");
        }else if(input4.Cavalry.equals("cavalry"))
            System.out.println("Cavalry Armies");
    }

    public void playerone(View view) {
       TextView teks = (TextView) findViewById(R.id.textView2);
       teks.setText("Win");


    }

    public void playertwo(View view) {
        TextView teks = (TextView) findViewById(R.id.textView2);
        teks.setText("Win");
    }
}