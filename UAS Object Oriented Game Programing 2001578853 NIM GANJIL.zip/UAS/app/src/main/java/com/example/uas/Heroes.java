package com.example.uas;

public class Heroes {
    String Infantry, Cavalry;

    public String getInfantry() {
        return Infantry;
    }

    public void setInfantry(String infantry) {
        Infantry = infantry;
    }

    public String getCavalry() {
        return Cavalry;
    }

    public void setCavalry(String cavalry) {
        Cavalry = cavalry;
    }


    class Infantry extends Heroes {
        String charcater1 = "Infantry";
    }
    public void H1() {
        Infantry myInfantry = new Infantry();
        System.out.printf(myInfantry.charcater1);
        myInfantry.boosted();
    }

    class Cavalry extends Heroes {
        String character2 = "Cavalry";
    }
    public void H2() {
        Cavalry myCavalry = new Cavalry();
        System.out.printf(myCavalry.character2);
        myCavalry.boosted();
    }



    public void boosted() {
        System.out.println("(boost 40% attack)");
    }
}
