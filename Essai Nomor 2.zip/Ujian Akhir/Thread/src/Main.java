
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Mythread thread1 = new Mythread();
		Myrunnable runnable1 = new Myrunnable();
		Thread thread2 = new Thread(runnable1);
		
		thread1.start();
		try {
			thread1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		thread2.start();
	}

}
