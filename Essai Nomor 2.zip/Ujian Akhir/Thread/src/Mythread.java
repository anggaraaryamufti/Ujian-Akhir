
public class Mythread extends Thread{
@Override
	public void run() {
	for(int i= 10;i>0;i--) {
		System.out.println("FuncA : "+i);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	System.out.println("FuncA telah selesai");
	}
}
